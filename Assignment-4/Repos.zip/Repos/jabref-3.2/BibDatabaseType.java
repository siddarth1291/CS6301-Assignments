package net.sf.jabref.model.database;

public enum BibDatabaseType {
    BIBTEX,
    BIBLATEX
}
